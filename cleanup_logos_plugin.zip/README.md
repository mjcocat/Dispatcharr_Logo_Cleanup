# Cleanup Unused Logos Plugin v1.1.1

Debug version to troubleshoot parameter passing.

## Version
1.1.1 - Debug release
