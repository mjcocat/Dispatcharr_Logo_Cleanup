import logging
from django.db.models import Q

logger = logging.getLogger(__name__)

class Plugin:
    name = "Cleanup Unused Logos"
    version = "1.1.1"
    description = "Delete logos that are not used by channels (optionally delete VOD-only logos)"
    author = "Community"
    
    fields = [
        {
            "id": "delete_vod_logos",
            "label": "Delete VOD-only logos",
            "type": "boolean",
            "default": False,
            "help_text": "Delete logos that are ONLY used by movies/series (not by channels)"
        },
        {
            "id": "delete_files",
            "label": "Delete local files",
            "type": "boolean",
            "default": False,
            "help_text": "Whether to delete local logo files from disk (if any exist)"
        },
        {
            "id": "batch_size",
            "label": "Batch size",
            "type": "number",
            "default": 5000,
            "help_text": "Number of logos to delete per batch (for large datasets)"
        }
    ]
    
    actions = [
        {
            "id": "cleanup",
            "label": "Cleanup Unused Logos",
            "description": "Remove logos not used by channels (optionally remove VOD-only logos)"
        }
    ]
    
    def run(self, action: str, params: dict, context: dict):
        if action != "cleanup":
            return {"success": False, "message": "Unknown action"}
            
        from apps.channels.models import Logo, Channel
        import os
        from django.conf import settings
        from django.apps import apps
        
        # DEBUG: Log what we received
        logger.info(f"DEBUG - Received params: {params}")
        logger.info(f"DEBUG - Received context: {context}")
        
        # Get settings - try multiple ways to read the parameter
        delete_vod_logos = params.get("delete_vod_logos", False)
        logger.info(f"DEBUG - delete_vod_logos from params.get(): {delete_vod_logos} (type: {type(delete_vod_logos)})")
        
        # Try reading from settings if params doesn't work
        if not delete_vod_logos and 'settings' in context:
            delete_vod_logos = context['settings'].get('delete_vod_logos', False)
            logger.info(f"DEBUG - delete_vod_logos from context.settings: {delete_vod_logos}")
        
        # Convert to boolean explicitly
        if isinstance(delete_vod_logos, str):
            delete_vod_logos = delete_vod_logos.lower() in ('true', '1', 'yes')
            logger.info(f"DEBUG - Converted string to boolean: {delete_vod_logos}")
        
        delete_files = params.get("delete_files", False)
        batch_size = int(params.get("batch_size", 5000))
        
        logger.info("=" * 60)
        logger.info("Starting Logo Cleanup Plugin v1.1.1")
        logger.info(f"Settings: delete_vod_logos={delete_vod_logos}, delete_files={delete_files}, batch_size={batch_size}")
        logger.info("=" * 60)
        
        # Count before
        total_logos_before = Logo.objects.count()
        total_channels = Channel.objects.count()
        logos_with_channels = Logo.objects.filter(channels__isnull=False).distinct().count()
        
        logger.info(f"Total logos before: {total_logos_before}")
        logger.info(f"Total channels: {total_channels}")
        logger.info(f"Logos used by channels: {logos_with_channels}")
        
        # Check VOD stats
        vod_stats = {}
        if apps.is_installed('apps.vod'):
            try:
                Movie = apps.get_model('vod', 'Movie')
                logos_with_movies = Logo.objects.filter(movie__isnull=False).distinct().count()
                total_movies = Movie.objects.count()
                vod_stats['movies'] = {'logos': logos_with_movies, 'total': total_movies}
                logger.info(f"Logos used by movies: {logos_with_movies} (Total movies: {total_movies})")
            except:
                logger.info("Movie model not found")
            
            try:
                Series = apps.get_model('vod', 'Series')
                logos_with_series = Logo.objects.filter(series__isnull=False).distinct().count()
                total_series = Series.objects.count()
                vod_stats['series'] = {'logos': logos_with_series, 'total': total_series}
                logger.info(f"Logos used by series: {logos_with_series} (Total series: {total_series})")
            except:
                logger.info("Series model not found")
        
        # Determine which logos to delete
        if delete_vod_logos:
            logger.info("✓ Mode: Deleting logos NOT used by channels (including VOD-only logos)")
            # Delete logos that have NO channel relationships
            unused_logos_query = Logo.objects.filter(channels__isnull=True)
        else:
            logger.info("✗ Mode: Deleting logos with NO relationships at all (safe mode)")
            # Delete only logos with NO relationships whatsoever
            unused_logos_query = Logo.objects.filter(
                Q(channels__isnull=True) &
                Q(movie__isnull=True) &
                Q(series__isnull=True)
            )
        
        unused_logos = unused_logos_query.distinct()
        unused_count = unused_logos.count()
        
        logger.info(f"Found {unused_count} logos to delete")
        
        if unused_count == 0:
            logger.info("No logos to delete. Cleanup complete.")
            return {
                "success": True,
                "logos_before": total_logos_before,
                "logos_deleted": 0,
                "logos_remaining": total_logos_before,
                "files_deleted": 0,
                "vod_stats": vod_stats,
                "message": "No logos to delete (check if 'Delete VOD-only logos' checkbox is enabled)"
            }
        
        # Warn user if deleting a lot of logos
        if unused_count > 10000:
            logger.warning(f"⚠️  About to delete {unused_count} logos! This may take several minutes...")
        
        # Delete local files if requested
        files_deleted = 0
        if delete_files:
            logger.info("Checking for local logo files to delete...")
            logos_dir = os.path.join(settings.MEDIA_ROOT, "logos")
            if os.path.exists(logos_dir):
                file_count = 0
                for logo in unused_logos.iterator(chunk_size=100):
                    file_count += 1
                    if logo.url and logo.url.startswith("/data"):
                        try:
                            if os.path.exists(logo.url):
                                os.remove(logo.url)
                                files_deleted += 1
                                if files_deleted % 100 == 0:
                                    logger.info(f"Deleted {files_deleted} files...")
                        except Exception as e:
                            logger.error(f"Error deleting file {logo.url}: {e}")
                    
                    if file_count % 1000 == 0:
                        logger.info(f"Checked {file_count} logos for files...")
                        
                logger.info(f"Total files deleted: {files_deleted}")
            else:
                logger.info(f"Logos directory does not exist: {logos_dir}")
        
        # Delete logos from database in batches
        logger.info(f"Deleting logos from database in batches of {batch_size}...")
        total_deleted = 0
        batch_num = 0
        
        while True:
            batch_num += 1
            
            # Re-query to get current logos to delete
            if delete_vod_logos:
                current_unused = Logo.objects.filter(channels__isnull=True)
            else:
                current_unused = Logo.objects.filter(
                    Q(channels__isnull=True) &
                    Q(movie__isnull=True) &
                    Q(series__isnull=True)
                )
            
            current_unused = current_unused.distinct()
            
            # Get batch of IDs to delete
            batch_ids = list(current_unused.values_list('id', flat=True)[:batch_size])
            
            if not batch_ids:
                logger.info("No more logos to delete")
                break
            
            # Delete batch
            deleted_count, details = Logo.objects.filter(id__in=batch_ids).delete()
            total_deleted += deleted_count
            
            progress_pct = (total_deleted / unused_count * 100) if unused_count > 0 else 0
            logger.info(f"Batch {batch_num}: Deleted {deleted_count} logos (Total: {total_deleted}/{unused_count} - {progress_pct:.1f}%)")
            
            # Safety check: if we've deleted more than we expected, stop
            if total_deleted >= unused_count:
                logger.info("Reached expected deletion count")
                break
                
            # If batch size is less than requested, we're probably done
            if len(batch_ids) < batch_size:
                logger.info("Last batch completed")
                break
        
        # Count after
        total_logos_after = Logo.objects.count()
        logos_with_channels_after = Logo.objects.filter(channels__isnull=False).distinct().count()
        
        logger.info("=" * 60)
        logger.info(f"Cleanup complete!")
        logger.info(f"Logos before: {total_logos_before}")
        logger.info(f"Logos deleted: {total_deleted}")
        logger.info(f"Logos remaining: {total_logos_after}")
        logger.info(f"Channel logos preserved: {logos_with_channels_after}")
        logger.info(f"Files deleted: {files_deleted}")
        logger.info("=" * 60)
        
        return {
            "success": True,
            "logos_before": total_logos_before,
            "logos_deleted": total_deleted,
            "logos_remaining": total_logos_after,
            "channel_logos_preserved": logos_with_channels_after,
            "files_deleted": files_deleted,
            "vod_stats": vod_stats,
            "message": f"Successfully deleted {total_deleted} logos. Remaining: {total_logos_after} (Channel logos: {logos_with_channels_after})"
        }
